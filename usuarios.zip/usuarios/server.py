from flask import Flask, render_template, request, redirect, session

from user import User
app = Flask(__name__)
app.secret_key = 'root'

#RUTA RAIZ
@app.route('/')
def index():
    return render_template('crear.html')

#RUTA MIXTA -  ACEPTA GET Y POST PARA EDITAR USUARIO
@app.route("/edit/<int:id_usuario>", methods=["GET", "POST"])
def editar_usuario(id_usuario):
    if request.method == "GET":
        data = {"id_usuario":id_usuario}
        un_usuario = User.show(data)
        return render_template('crear.html', un_usuario=un_usuario)
    data = {
        "fname":request.form['fname'],
        "lname":request.form['lname'],
        "email":request.form['email'],
        "id":id_usuario

    }
    User.edit(data)
    return redirect('/ver')
    
#RUTA CREATE
@app.route('/crear_usuario', methods=["POST"])
def crear_usuario():

    data = {
        "fname":request.form['fname'],
        "lname":request.form['lname'],
        "email":request.form['email']
    }

    User.save(data)
    return redirect('/ver')

#RUTA DE LECTURA
@app.route('/ver', methods=['GET'])
def ver ():
    print(request.form)
    users = User.get_all()
    print(users)
    return render_template('leer.html',users=users)

#RUTA DE LECTURA DE UN SOLO REGISTRO
@app.route('/usuario/<int:id_usuario>',methods=['GET'])
def user(id_usuario):
    data = {
        "id_usuario":id_usuario
    }
    un_usuario = User.show(data)
    return render_template('usuarios.html',un_usuario=un_usuario)

#RUTA BORRAR
@app.route("/borrar/<int:id_usuario>")
def borrar_registro(id_usuario):
    data={"id":id_usuario}
    User.delete(data)
    return redirect("/ver")


if __name__ == "__main__": 
    app.run(debug=True)